﻿namespace EventManagement.DAL;

public class Class1
{

}
